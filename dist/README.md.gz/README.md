# Corporesapiens

Aplicativo web instalável e offline para registrar a rotina de academia em um único lugar.

## Módulos

- painel com treinos, sequência, volume e recordes;
- criação e edição de fichas;
- treino ativo com séries, cargas, repetições e descanso;
- histórico e volume;
- calculadora de anilhas e aquecimento configurável;
- cronômetro;
- estimativa matemática de 1RM;
- calculadora de ritmo e velocidade de corrida;
- frequência e calendário;
- recordes pessoais;
- medidas corporais com gráfico local;
- anotações de regulagens de aparelhos;
- exportação e importação de backup;
- PWA offline e sem login.

## Executar localmente

```bash
python3 -m http.server 8080
```

Abra `http://localhost:8080`.

## Privacidade

Os dados são armazenados no `localStorage` do navegador. Não há servidor de dados no MVP.

## Limites

O aplicativo organiza dados fornecidos pelo usuário e realiza cálculos matemáticos. Não prescreve exercício, carga, dieta, tratamento ou regulagem segura de aparelhos. Validação profissional continua necessária.

## Estado

Protótipo funcional. Não representa publicação em lojas ou produção.


## Novas funções de autoevolução

- análise local das sessões concluídas;
- resumo automático de frequência, séries e volume;
- identificação do exercício mais frequente;
- lembretes organizacionais de exercícios sem registro recente;
- clonagem automática do treino mais utilizado;
- criação de variação de treino para revisão;
- montagem automática de semana com até três fichas;
- detecção automática de recordes a partir das séries concluídas;
- nenhuma transmissão dos dados para serviços externos.

As variações e observações automáticas são recursos de organização. Não constituem prescrição, recomendação médica ou orientação profissional.


## Versão

Corporesapiens 0.2 — aplicação web progressiva, offline e com dados locais.
