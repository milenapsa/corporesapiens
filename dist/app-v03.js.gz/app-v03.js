
(() => {
  "use strict";

  const EXERCISES = [
    ["Supino reto","Peito","Barra"],["Supino inclinado","Peito","Halteres"],
    ["Crucifixo","Peito","Halteres"],["Crossover","Peito","Polia"],
    ["Agachamento livre","Pernas","Barra"],["Leg press","Pernas","Máquina"],
    ["Cadeira extensora","Pernas","Máquina"],["Mesa flexora","Pernas","Máquina"],
    ["Levantamento terra","Posterior","Barra"],["Stiff","Posterior","Barra"],
    ["Elevação pélvica","Glúteos","Barra"],["Abdução de quadril","Glúteos","Máquina"],
    ["Puxada frontal","Costas","Polia"],["Remada baixa","Costas","Polia"],
    ["Remada curvada","Costas","Barra"],["Barra fixa","Costas","Peso corporal"],
    ["Desenvolvimento","Ombros","Halteres"],["Elevação lateral","Ombros","Halteres"],
    ["Rosca direta","Bíceps","Barra"],["Rosca alternada","Bíceps","Halteres"],
    ["Tríceps corda","Tríceps","Polia"],["Tríceps testa","Tríceps","Barra"],
    ["Panturrilha em pé","Panturrilhas","Máquina"],["Panturrilha sentada","Panturrilhas","Máquina"],
    ["Prancha","Core","Peso corporal"],["Abdominal máquina","Core","Máquina"]
  ];

  const TEMPLATES = [
    {
      name:"A — Peito e tríceps",
      notes:"Modelo rápido editável. Ajuste com seu profissional.",
      exercises:[
        ["Supino reto",4,"8-10",120],["Supino inclinado",3,"8-12",90],
        ["Crossover",3,"10-15",75],["Tríceps corda",3,"10-15",75]
      ]
    },
    {
      name:"B — Costas e bíceps",
      notes:"Modelo rápido editável. Ajuste com seu profissional.",
      exercises:[
        ["Puxada frontal",4,"8-12",90],["Remada baixa",4,"8-12",90],
        ["Remada curvada",3,"8-10",120],["Rosca direta",3,"8-12",75]
      ]
    },
    {
      name:"C — Pernas",
      notes:"Modelo rápido editável. Ajuste com seu profissional.",
      exercises:[
        ["Agachamento livre",4,"6-10",150],["Leg press",4,"10-15",120],
        ["Cadeira extensora",3,"12-15",75],["Mesa flexora",3,"10-15",75],
        ["Panturrilha em pé",4,"12-20",60]
      ]
    }
  ];

  function addV03UI(){
    if(document.getElementById("v03Hub")) return;
    const more = document.getElementById("moreView");
    if(!more) return;

    const card = document.createElement("div");
    card.id = "v03Hub";
    card.className = "card v03-card";
    card.innerHTML = `
      <div class="section-head">
        <div><p class="eyebrow">CORPORESAPIENS 0.3</p><h2>Biblioteca e evolução</h2></div>
        <span class="chip">local</span>
      </div>
      <p class="muted">Recursos de organização. Modelos e sugestões devem ser revisados antes do uso.</p>
      <div class="v03-actions">
        <button id="openLibraryBtn" class="button secondary">Biblioteca de exercícios</button>
        <button id="openTemplatesBtn" class="button secondary">Modelos rápidos</button>
        <button id="repeatLastBtn" class="button secondary">Repetir último treino</button>
        <button id="openChartsBtn" class="button secondary">Gráficos de evolução</button>
      </div>
      <div id="v03MiniSummary" class="top-gap"></div>
    `;
    const smart = more.querySelector(".smart-card");
    more.insertBefore(card, smart || more.firstChild);

    document.getElementById("openLibraryBtn").onclick = libraryModal;
    document.getElementById("openTemplatesBtn").onclick = templatesModal;
    document.getElementById("repeatLastBtn").onclick = repeatLastWorkout;
    document.getElementById("openChartsBtn").onclick = chartsModal;
    renderV03Summary();
  }

  function libraryModal(){
    openModal("Biblioteca de exercícios", `
      <div class="form-grid cols-2">
        <label>Pesquisar<input id="libSearch" placeholder="Ex.: supino, costas"></label>
        <label>Grupo
          <select id="libGroup"><option value="">Todos</option></select>
        </label>
      </div>
      <div id="libraryList" class="library-grid top-gap"></div>
    `);
    const groups=[...new Set(EXERCISES.map(x=>x[1]))].sort();
    document.getElementById("libGroup").innerHTML += groups.map(g=>`<option>${esc(g)}</option>`).join("");
    const draw=()=>{
      const q=document.getElementById("libSearch").value.trim().toLowerCase();
      const g=document.getElementById("libGroup").value;
      const rows=EXERCISES.filter(x=>(!q||x.join(" ").toLowerCase().includes(q))&&(!g||x[1]===g));
      document.getElementById("libraryList").innerHTML=rows.length?rows.map(x=>`
        <article class="library-item">
          <div><strong>${esc(x[0])}</strong><div class="meta">${esc(x[1])} · ${esc(x[2])}</div></div>
          <button class="button secondary compact" data-lib-name="${esc(x[0])}">Criar ficha</button>
        </article>`).join(""):`<div class="empty">Nenhum exercício encontrado.</div>`;
      document.querySelectorAll("[data-lib-name]").forEach(b=>b.onclick=()=>createSingleExercisePlan(b.dataset.libName));
    };
    document.getElementById("libSearch").oninput=draw;
    document.getElementById("libGroup").onchange=draw;
    draw();
  }

  function createSingleExercisePlan(name){
    const p={id:uid(),name:`Treino — ${name}`,notes:"Ficha criada pela biblioteca. Revise séries, repetições e descanso.",exercises:[
      {id:uid(),name,sets:3,reps:"8-12",rest:90}
    ]};
    state.plans.push(p); closeModal(); save(); nav("workouts"); toast("Ficha criada para edição");
  }

  function templatesModal(){
    openModal("Modelos rápidos", `
      <p class="muted">Modelos organizacionais editáveis. Não constituem prescrição.</p>
      <div class="stack">${TEMPLATES.map((t,i)=>`
        <article class="list-item">
          <div class="list-item-head"><div><strong>${esc(t.name)}</strong><div class="meta">${t.exercises.length} exercícios</div></div>
          <button class="button primary compact" data-template="${i}">Adicionar</button></div>
          <div class="chips">${t.exercises.map(e=>`<span class="chip">${esc(e[0])}</span>`).join("")}</div>
        </article>`).join("")}</div>
    `);
    document.querySelectorAll("[data-template]").forEach(b=>b.onclick=()=>{
      const t=TEMPLATES[+b.dataset.template];
      state.plans.push({
        id:uid(),name:t.name,notes:t.notes,
        exercises:t.exercises.map(e=>({id:uid(),name:e[0],sets:e[1],reps:e[2],rest:e[3]}))
      });
      closeModal(); save(); nav("workouts"); toast("Modelo adicionado");
    });
  }

  function repeatLastWorkout(){
    const last=[...state.sessions].sort((a,b)=>b.finishedAt-a.finishedAt)[0];
    if(!last) return toast("Conclua um treino antes de repetir");
    if(state.activeSession&&!confirm("Substituir o treino em andamento?")) return;
    state.activeSession={
      id:uid(),planId:last.planId||null,name:`${last.name} — repetir`,startedAt:Date.now(),notes:"",
      exercises:(last.exercises||[]).map(e=>({
        id:uid(),name:e.name,targetReps:e.targetReps||"",
        rest:e.rest||90,
        sets:(e.sets||[]).map(s=>({id:uid(),weight:s.weight||"",reps:s.reps||"",done:false}))
      }))
    };
    save(); nav("workouts"); toast("Último treino carregado");
  }

  function seriesByExercise(){
    const map={};
    state.sessions.forEach(s=>(s.exercises||[]).forEach(e=>(e.sets||[]).forEach(set=>{
      if(!map[e.name]) map[e.name]=[];
      map[e.name].push({
        date:new Date(s.finishedAt),
        weight:Number(set.weight)||0,
        reps:Number(set.reps)||0,
        volume:(Number(set.weight)||0)*(Number(set.reps)||0)
      });
    })));
    return map;
  }

  function svgChart(points, field){
    if(points.length<2) return `<div class="empty">São necessários ao menos dois registros.</div>`;
    const w=640,h=210,pad=28;
    const vals=points.map(x=>x[field]);
    const min=Math.min(...vals),max=Math.max(...vals),range=max-min||1;
    const coords=points.map((x,i)=>{
      const px=pad+i*(w-pad*2)/(points.length-1);
      const py=h-pad-(x[field]-min)*(h-pad*2)/range;
      return [px,py];
    });
    return `<svg class="v03-chart" viewBox="0 0 ${w} ${h}" role="img" aria-label="Gráfico de evolução">
      <line x1="${pad}" y1="${h-pad}" x2="${w-pad}" y2="${h-pad}" class="axis"/>
      <polyline points="${coords.map(x=>x.join(",")).join(" ")}" class="chart-line"/>
      ${coords.map((x,i)=>`<circle cx="${x[0]}" cy="${x[1]}" r="4"><title>${num(vals[i])}</title></circle>`).join("")}
    </svg>`;
  }

  function chartsModal(){
    const map=seriesByExercise(), names=Object.keys(map).sort();
    openModal("Gráficos de evolução", names.length?`
      <div class="form-grid cols-2">
        <label>Exercício<select id="chartExercise">${names.map(n=>`<option>${esc(n)}</option>`).join("")}</select></label>
        <label>Métrica<select id="chartMetric"><option value="weight">Carga</option><option value="volume">Volume da série</option><option value="reps">Repetições</option></select></label>
      </div>
      <div id="chartMount" class="top-gap"></div>
    `:`<div class="empty">Conclua treinos para gerar gráficos.</div>`);
    if(!names.length) return;
    const draw=()=>{
      const name=document.getElementById("chartExercise").value;
      const field=document.getElementById("chartMetric").value;
      const points=[...map[name]].sort((a,b)=>a.date-b.date).slice(-20);
      document.getElementById("chartMount").innerHTML=`
        ${svgChart(points,field)}
        <div class="metric-grid">
          <div class="metric"><span>Registros</span><strong>${points.length}</strong></div>
          <div class="metric"><span>Primeiro</span><strong>${num(points[0]?.[field]||0)}</strong></div>
          <div class="metric"><span>Último</span><strong>${num(points.at(-1)?.[field]||0)}</strong></div>
        </div>`;
    };
    document.getElementById("chartExercise").onchange=draw;
    document.getElementById("chartMetric").onchange=draw;
    draw();
  }

  function renderV03Summary(){
    const m=document.getElementById("v03MiniSummary");
    if(!m) return;
    const exercises=new Set(state.sessions.flatMap(s=>(s.exercises||[]).map(e=>e.name)));
    m.innerHTML=`<div class="metric-grid">
      <div class="metric"><span>Biblioteca</span><strong>${EXERCISES.length}</strong></div>
      <div class="metric"><span>Modelos</span><strong>${TEMPLATES.length}</strong></div>
      <div class="metric"><span>Exercícios usados</span><strong>${exercises.size}</strong></div>
    </div>`;
  }

  // Preenche cargas e repetições com a última sessão do mesmo plano.
  const originalStartPlan = startPlan;
  startPlan = function(id){
    originalStartPlan(id);
    if(!state.activeSession) return;
    const previous=[...state.sessions].filter(s=>s.planId===id).sort((a,b)=>b.finishedAt-a.finishedAt)[0];
    if(!previous) return;
    state.activeSession.exercises.forEach(e=>{
      const old=previous.exercises.find(x=>x.name.toLowerCase()===e.name.toLowerCase());
      if(!old) return;
      e.sets.forEach((set,i)=>{
        const oldSet=old.sets[i]||old.sets.at(-1);
        if(oldSet){set.weight=oldSet.weight||"";set.reps=oldSet.reps||"";}
      });
    });
    saveSilent(); renderActiveWorkout(); toast("Cargas anteriores preenchidas");
  };

  const originalRenderAll = renderAll;
  renderAll = function(){ originalRenderAll(); addV03UI(); renderV03Summary(); };

  addV03UI();
  renderV03Summary();
})();
